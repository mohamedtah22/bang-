import React, { useMemo } from "react";
import { View, Text, StyleSheet } from "react-native";
import WoodButton from "../../game/WoodButton";
import { CHARACTER_DETAILS } from "../index";

type Props = {
  hp: number;
  maxHp: number;
  selectedIds: Set<string>;
  onHeal: (cardIds: string[]) => void;
  onClear: () => void;
  selectMode?: boolean;
  onToggleSelectMode?: () => void;
};

export function SidKetchumPanel({
  hp,
  maxHp,
  selectedIds,
  onHeal,
  onClear,
  selectMode,
  onToggleSelectMode,
}: Props) {
  const arr = useMemo(() => Array.from(selectedIds), [selectedIds]);
  const canHeal = hp < maxHp && arr.length === 2;
  const details = CHARACTER_DETAILS.sid_ketchum;

  return (
    <View style={s.box}>
      <Text style={s.desc}>{details.effect}</Text>

      <View style={s.infoBlock}>
        <Text style={s.infoLabel}>WHEN</Text>
        <Text style={s.infoText}>{details.timing}</Text>
      </View>

      <Text style={s.hint}>
        HP: <Text style={s.bold}>{hp}</Text> / {maxHp} • Selected: <Text style={s.bold}>{arr.length}</Text> / 2
      </Text>

      <View style={s.row}>
        {onToggleSelectMode ? (
          <WoodButton
            title={selectMode ? "Selecting" : "Select 2 cards"}
            onPress={onToggleSelectMode}
            style={s.btnItem}
          />
        ) : null}

        <WoodButton title="Clear" onPress={onClear} style={s.btnItem} />
        <WoodButton title="Heal +1" disabled={!canHeal} onPress={() => onHeal(arr)} style={s.btnItem} />
      </View>

      <Text style={s.note}>{details.hint ?? "Enable select mode, then tap two cards in your hand."}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  box: {
    padding: 10,
    borderRadius: 16,
    backgroundColor: "rgba(0,0,0,0.18)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
  },
  title: { color: "white", fontWeight: "900", fontSize: 14 },
  desc: { color: "rgba(255,255,255,0.82)", marginTop: 6, fontSize: 12, lineHeight: 17 },
  infoBlock: {
    marginTop: 10,
    padding: 10,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  infoLabel: { color: "#FFD28A", fontWeight: "900", fontSize: 10, letterSpacing: 0.7 },
  infoText: { color: "rgba(255,255,255,0.88)", marginTop: 5, fontSize: 12, lineHeight: 17 },
  hint: { marginTop: 10, color: "rgba(255,255,255,0.70)", fontSize: 12 },
  bold: { fontWeight: "900", color: "white" },
  row: { flexDirection: "row", gap: 10, marginTop: 10, flexWrap: "wrap" },
  btnItem: { minWidth: 128 },
  note: { marginTop: 8, color: "rgba(255,255,255,0.55)", fontSize: 11 },
});
